﻿local achievementController = {}

achievementController.name = "achievementHelper/achievementController"
achievementController.depth = 0
achievementController.texture = "Loenn/AchievementHelper/AchievementController"
achievementController.placements = {
    name = "controller",
    data = {
        condition = "",
        modName = "",
        achievementName = ""
    }
}

return achievementController