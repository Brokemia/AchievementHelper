﻿local trigger = {}

trigger.name = "achievementHelper/triggerAchievement"
trigger.placements = {
    name = "trigger",
    data = {
        modName = "",
        achievementName = ""
    }
}

return trigger